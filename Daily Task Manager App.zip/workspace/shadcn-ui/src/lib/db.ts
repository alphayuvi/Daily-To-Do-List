import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';

export type RepeatType = 'none' | 'daily' | 'weekly' | 'monthly' | 'custom';

export interface DayOfWeek {
  monday: boolean;
  tuesday: boolean;
  wednesday: boolean;
  thursday: boolean;
  friday: boolean;
  saturday: boolean;
  sunday: boolean;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  dueDate: string | null;
  dueTime: string | null;
  repeat: RepeatType;
  customDays: DayOfWeek | null;
  priority: number;
  createdAt: string;
  lastCompleted: string | null;
}

export interface TodoStore {
  tasks: Task[];
  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTask: (id: string, task: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  completeTask: (id: string) => void;
  reorderTasks: (startIndex: number, endIndex: number) => void;
  getTasksDueToday: () => Task[];
  getTasksDueSoon: () => Task[];
  resetRecurringTasks: () => void;
}

// Reset completed recurring tasks at midnight
const checkForTaskReset = () => {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  
  // If it's midnight (00:00 to 00:05), check for recurring tasks
  if (hours === 0 && minutes < 5) {
    useTodoStore.getState().resetRecurringTasks();
  }
};

// Check every minute
setInterval(checkForTaskReset, 60 * 1000);

// Helper function to determine if a task should repeat today
export const shouldTaskRepeatToday = (task: Task): boolean => {
  if (!task.repeat || task.repeat === 'none') return false;
  if (task.repeat === 'daily') return true;

  const today = new Date();
  
  if (task.repeat === 'weekly') {
    if (!task.lastCompleted) return true;
    
    const lastCompleted = new Date(task.lastCompleted);
    const diffTime = today.getTime() - lastCompleted.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays >= 7;
  }
  
  if (task.repeat === 'monthly') {
    if (!task.lastCompleted) return true;
    
    const lastCompleted = new Date(task.lastCompleted);
    if (today.getDate() === lastCompleted.getDate() && 
        today.getMonth() !== lastCompleted.getMonth()) {
      return true;
    }
    return false;
  }
  
  if (task.repeat === 'custom' && task.customDays) {
    const dayOfWeek = today.getDay();
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const todayName = days[dayOfWeek] as keyof DayOfWeek;
    
    return task.customDays[todayName];
  }
  
  return false;
};

export const useTodoStore = create<TodoStore>()(
  persist(
    (set, get) => ({
      tasks: [],
      
      addTask: (task) => set((state) => ({
        tasks: [
          ...state.tasks,
          {
            ...task,
            id: uuidv4(),
            createdAt: new Date().toISOString(),
          }
        ].sort((a, b) => a.priority - b.priority)
      })),
      
      updateTask: (id, updatedTask) => set((state) => ({
        tasks: state.tasks.map((task) =>
          task.id === id ? { ...task, ...updatedTask } : task
        ).sort((a, b) => a.priority - b.priority)
      })),
      
      deleteTask: (id) => set((state) => ({
        tasks: state.tasks.filter((task) => task.id !== id)
      })),
      
      completeTask: (id) => set((state) => {
        const taskToComplete = state.tasks.find((task) => task.id === id);
        if (!taskToComplete) return state;
        
        const now = new Date().toISOString();
        
        return {
          tasks: state.tasks.map((task) =>
            task.id === id ? { ...task, completed: true, lastCompleted: now } : task
          )
        };
      }),
      
      reorderTasks: (startIndex, endIndex) => set((state) => {
        const result = Array.from(state.tasks);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        
        // Update priorities
        const updatedTasks = result.map((task, index) => ({
          ...task,
          priority: index
        }));
        
        return { tasks: updatedTasks };
      }),
      
      getTasksDueToday: () => {
        const tasks = get().tasks;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        return tasks.filter((task) => {
          if (task.completed) {
            // Check if it's a recurring task that should reappear
            if (shouldTaskRepeatToday(task)) {
              return true;
            }
            return false;
          }
          
          if (!task.dueDate) return true; // Tasks with no due date always shown
          
          const dueDate = new Date(task.dueDate);
          dueDate.setHours(0, 0, 0, 0);
          
          return dueDate <= today;
        });
      },
      
      getTasksDueSoon: () => {
        const tasks = get().tasks;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const nextWeek = new Date(today);
        nextWeek.setDate(today.getDate() + 7);
        
        return tasks.filter((task) => {
          if (task.completed && !shouldTaskRepeatToday(task)) return false;
          
          if (!task.dueDate) return false;
          
          const dueDate = new Date(task.dueDate);
          dueDate.setHours(0, 0, 0, 0);
          
          return dueDate > today && dueDate <= nextWeek;
        });
      },
      
      resetRecurringTasks: () => set((state) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        return {
          tasks: state.tasks.map((task) => {
            if (!task.completed) return task;
            
            if (shouldTaskRepeatToday(task)) {
              return {
                ...task,
                completed: false
              };
            }
            
            return task;
          })
        };
      }),
    }),
    {
      name: 'todo-storage',
    }
  )
);